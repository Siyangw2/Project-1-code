########################################################
# The prediction results are visually analyzed and the broken line diagram is drawn.
# Due to the large amount of prediction data, some prediction data are selected and displayed in the form of subgraph.
# Draw three subgraphs for each line and draw two lines in total.
# Each sub graph shows 100 pieces of data.
########################################################
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('DT_model_3.csv')

# Draw the broken line diagram of decision tree regression model prediction
plt.figure(figsize=(18, 9))
for i in range(6):
    plt.subplot(321+i)
    plt.plot(data.loc[i*100:100+i*100, ['true']], label='true', c='orange')
    plt.plot(data.loc[i*100:100+i*100, ['pred']], label='pred', c='green')
    plt.xlabel('Time', size=16)
    plt.ylabel('total amount', size=16)
    plt.xticks(size=16)
    plt.yticks(size=16)
    plt.legend()
plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=0.5)
plt.savefig('DT_model_pred.png')
plt.show()

# Draw the broken line diagram predicted by the two models
data_1 = pd.read_csv('LR_model_3.csv')
plt.figure(figsize=(18, 9))
for i in range(6):
    plt.subplot(321+i)
    plt.plot(data.loc[i*100:100+i*100, ['true']], label='true')
    plt.plot(data.loc[i*100:100+i*100, ['pred']], label='lr_pred', c='orange')
    plt.plot(data_1.loc[i*100:100+i*100, ['pred']], label='dt_pred', c='green')
    plt.xlabel('Time', size=16)
    plt.ylabel('total amount', size=16)
    plt.xticks(size=16)
    plt.yticks(size=16)
    plt.legend()
plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=0.5)
plt.savefig('DT_LR_pred.png')
plt.show()